import React from 'react';
import CardImg from '../../assets/img/team.png';
import './cards.css'
const Card = () => {
    return (
        <div className='card-item'>
           <div className="card-item__texts">
               <span>1.</span>
               <p>Falcons</p>
           </div>
            <div className="card-item__img">
                <img src={CardImg} alt=""/>
            </div>
        </div>
    );
}

export default Card;
