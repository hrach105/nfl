import React from 'react';
import { SettingsInput } from '../SettingsInput';

const SelectAll = () => {
    return (
        <div className='select-all-cards'>
            <SettingsInput 
                settingsInputType='checkbox'
            />
            <span>Select all</span>
            
        </div>
    );
}

export default SelectAll;
