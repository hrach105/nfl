import React, {useState} from 'react';

function EditSwitch() {
    const [toggleSwitch, setToggleEditSwitch] = useState(true);

    return (
        <div className='switcher-parent'>
            <label className="switch">
                <input type="checkbox" onChange={() => setToggleEditSwitch(!toggleSwitch)}/>
                <span className="slider round"></span>
            </label>
            <span className='default-text'>Edit draft order</span>
        </div>
    );
}

export default EditSwitch;