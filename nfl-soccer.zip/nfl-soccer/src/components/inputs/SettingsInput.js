import React from 'react'

export const SettingsInput = ({
    settingsInputId = "",
    settingsInputClassName = "",
    settingsInputType = "",
    settingsInputName = "",
    settingsInputValue = "",
    onSettingsInputChange,
    settingsInputLabel = "",
 }) => {
    return (
       <label htmlFor={settingsInputId} className={`labelStyle ${settingsInputClassName}`}>
          {settingsInputLabel}
          <input
             id={settingsInputId}
             type={settingsInputType}
             name={settingsInputName}
             value={settingsInputValue}
             onChange={onSettingsInputChange}
          />
       </label>
    );
 }; 