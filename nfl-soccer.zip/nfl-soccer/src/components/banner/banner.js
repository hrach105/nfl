import React from 'react';
import TeamLogo from '../../assets/img/team-logo.png';
import bannerBg from '../../assets/img/home-bg.png'
import './banner.css';
const Banner = () => {
    return (
        <div className='banner' style={{backgroundImage: `url(${bannerBg})`}}>
            <img src={TeamLogo} alt="" />
        </div>
    );
}

export default Banner;
