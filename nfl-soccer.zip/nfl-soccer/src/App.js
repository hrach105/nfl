import Home from './pages/home/home';
import Layout from './layout';
import { Routes, Route} from "react-router-dom";
import './app.css';
function App() {
  return (
    <>
      <Routes>
          <Route path="/" element={<Layout />} >
            <Route index element={<Home />} />
          </Route>
      </Routes>
    </>
  );
}

export default App;
