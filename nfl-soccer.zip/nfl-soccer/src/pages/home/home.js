import React, { useState } from 'react';
import Banner from '../../components/banner/banner';
import Card from '../../components/cards/card';
import SelectAll from '../../components/inputs/select-all-btn/selectAll';
import { SettingsInput } from '../../components/inputs/SettingsInput';
import { getRadios } from './constants';
import './home.css';
import EditSwitch from "../../components/inputs/editSwitch";

const Home = () => {
    const [currentRadio, setCurrentRadio] = useState(false);
    const [currentRange, setCurrentRange] = useState('');
    const [positional, setPositional] = useState(false)
    const [toggleSwitch, setToggleSwitch] = useState(true);
    const [draft, setDraft] = useState(false);
    const [randomnes, setRandomnes] = useState(false);
    const radios = getRadios(7); 

    return (
        <>
            <Banner />
            <div className="main-container">
               <div className='wrapper'>
                    <div className="settings">
                        <form action="">
                                <p className='set-title'>Rounds</p>
                                <div className='radio-group'>
                                    {radios.map((radio, index) => {
                                        return (
                                            <SettingsInput
                                                key={index} 
                                                settingsInputId={radio} 
                                                settingsInputClassName={"radio-input"} 
                                                settingsInputName={"radioInput"} 
                                                settingsInputType={"radio"}
                                                settingsInputValue={currentRadio}
                                                onSettingsInputChange={(event) => setCurrentRadio(event.target.value)} 
                                            />
                                        );
                                    })}
                                </div>
                            <div className="speed">
                            <p className='set-title'>Speed</p>
                                <SettingsInput 
                                        settingsInputClassName={"range-input"} 
                                        settingsInputType='range'
                                        settingsInputValue={currentRange}
                                        onSettingsInputChange={(event) => setCurrentRange(event.target.value)} 
                                />
                                <div className='speed-slow'>
                                    <span>slow</span>
                                    <span>fast</span>
                                </div>
                            </div>
                            <div className="advanced-settings">
                                <p className='set-title'>Advanced SEtting</p>
                                <p>How simulated teams pick</p>
                               <div className='switcher-parent'>
                                <label class="switch">
                                        <input type="checkbox" onChange={()=>setToggleSwitch(!toggleSwitch)}/>
                                        <span class="slider round"></span>
                                    </label>
                                    <span className='default-text'>Use defaults</span>
                               </div>
                               
                            </div>
                            {
                                toggleSwitch && (
                                    <div className='advance-settings-block'>
                                            <div className='advanced-setting-item'>
                                                <p>Care for positional value</p>
                                                <SettingsInput
                                                    settingsInputClassName={"range-input"}
                                                    settingsInputType='range'
                                                    settingsInputValue={positional}
                                                    onSettingsInputChange={(event) => setPositional(event.target.value)}
                                                />
                                               <div className='speed-slow'>
                                                <span>slow</span>
                                                <span>fast</span>
                                               </div>
                                            </div>
                                            <div className='advanced-setting-item'>
                                                <p>Draft for needs</p>
                                                <SettingsInput
                                                        settingsInputClassName={"range-input"}
                                                        settingsInputType='range'
                                                        settingsInputValue={draft}
                                                        onSettingsInputChange={(event) => setDraft(event.target.value)}
                                                />
                                                <div className='speed-slow'>
                                                <span>slow</span>
                                                <span>fast</span>
                                               </div>
                                            </div>
                                            <div className='advanced-setting-item'>
                                                <p>Randomness</p>
                                            <SettingsInput
                                                    settingsInputClassName={"range-input"}
                                                    settingsInputType='range'
                                                    settingsInputValue={randomnes}
                                                    onSettingsInputChange={(event) => setRandomnes(event.target.value)}
                                            />
                                            <div className='speed-slow'>
                                                <span>slow</span>
                                                <span>fast</span>
                                               </div>
                                            </div>
                                    </div>
                                )
                            }
                        </form>
                    </div> 
                    <div className="cards">
                       <div className="cards-heading">
                            <h2>Select Your Team(s)</h2>
                            <p>Draft order is simulated</p>
                            <div className="select-all">
                                <div className='card-header'>
                                    <SelectAll />
                                    <EditSwitch />
                                </div>
                            </div>
                            <div className="all-teams">
                                <Card />
                                <Card />
                                <Card />
                                <Card />
                                <Card />
                                <Card />
                                <Card />
                                <Card />
                                <Card />
                                <Card />
                            </div>
                       </div>
                    </div>
               </div>
           </div> 
        </>
    );
}

export default Home;
