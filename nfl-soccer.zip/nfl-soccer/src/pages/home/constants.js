export function getRadios(quantity=2) {
    if(typeof(quantity) === "number") {
        const elements = [];
        for(let i=0; i<quantity; i++) {
            elements.push(i);
        }
        return elements;    
    }   
    return [1, 2];
}